window.ACADEMY_CONFIG = {
  version: '3.11.0',
  updated: '11 August 2026',
  syncUrl: 'https://script.google.com/macros/s/AKfycbxdqtdKgIBi9hD0N63FLNOFPLPxgLUA05lGGz-ft1I39ihZQfnqktsZ5s9i6Ib3CP9Zvw/exec',
  adminPinLabel: 'Administrator Access',
  academyName: 'V | Academy',
  subtitle: 'Learn work. Use AI.'
};
